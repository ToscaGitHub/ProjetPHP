<?php

namespace App\Controller;

use App\Entity\Recipe;
use App\Form\RecipeType;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

class RecipeController extends AbstractController
{
    #[Route('/', name: 'app_homepage')]
    
    public function homepage(EntityManagerInterface $entityManager)
    {
        $repository = $entityManager->getRepository(Recipe::class);
        $recipe = $repository->findAll();

        return $this->render('recipe/homepage.html.twig', [
            'recipe' => $recipe,
        ]);
    }

    #[Route('/recipe/new', name: 'app_recipe_new')]

    public function new(Request $request, EntityManagerInterface $entityManager)
    {
        $recipe = new Recipe();
        $form = $this->createForm(RecipeType::class, $recipe);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $recipe = $form->getData();
            $entityManager->persist($recipe);
            $entityManager->flush();

            return $this->redirectToRoute('app_recipe_show', ['name' => $recipe->getName()]);
        }

        return $this->render('recipe/new.html.twig', ['form' => $form->createView()]);

    }

    #[Route('/recipe/{name}', name: 'app_recipe_show')]

    public function show(Recipe $recipe)
    {
        return $this->render('recipe/show.html.twig', ['recipe' => $recipe,]);
    }

    
    #[Route('/recipe/{name}/edit', name: 'app_recipe_edit')]

    public function edit(Recipe $recipe, Request $request,  EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(RecipeType::class, $recipe);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {  
            $entityManager->flush();
        }
        

        return $this->render('recipe/edit.html.twig', [
            'form' => $form->createView(),
            'recipe'=> $recipe,
        ]);
    }

    
    #[Route('/recipe/{name}/delete', name: 'app_recipe_delete')]

    public function delete(Recipe $recipe, EntityManagerInterface $entityManager)
    {
        $entityManager->remove($recipe);
        $entityManager->flush();

        return $this->redirectToRoute('app_homepage');
    }

}
